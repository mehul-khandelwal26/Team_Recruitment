"""Team-level score aggregation."""
