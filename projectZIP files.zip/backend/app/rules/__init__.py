"""Configurable eligibility rules engine."""
