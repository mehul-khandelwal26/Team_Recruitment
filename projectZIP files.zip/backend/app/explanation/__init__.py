"""Human-readable scoring explanations."""
